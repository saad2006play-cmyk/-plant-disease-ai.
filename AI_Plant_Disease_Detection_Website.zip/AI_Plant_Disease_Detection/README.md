# AI Plant Disease Detection (Kurdish + English)

Mobile-friendly Gradio website using `malifiahm/plant_disease_classification` (38 classes).

## Deploy free on Hugging Face Spaces

1. Sign in at https://huggingface.co/ (create an account if needed).
2. Open https://huggingface.co/new-space
3. Enter a Space name such as `plant-disease-ai`.
4. Choose **Gradio** as the SDK and **Public** visibility, then create it.
5. In the Space's Files page, upload `app.py` and `requirements.txt` from this ZIP.
6. Wait for the build. First startup may take several minutes because the model is about 343 MB.
7. Open the exact public URL shown by Hugging Face (usually ends in `.hf.space`).
8. On your phone, open the link in Chrome, choose Kurdish or English, select a clear leaf photo, then tap Analyze.

## Notes
- Public visibility lets anyone with the link access it.
- Free Spaces may sleep or start slowly.
- The confidence score is not a guarantee of correctness.
- Confirm results with an agricultural expert before choosing treatments.
