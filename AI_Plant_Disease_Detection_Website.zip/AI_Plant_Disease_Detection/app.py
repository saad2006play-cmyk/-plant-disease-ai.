import os
import torch
import gradio as gr
from PIL import Image
from transformers import AutoImageProcessor, AutoModelForImageClassification

MODEL_ID = os.getenv("MODEL_ID", "malifiahm/plant_disease_classification")
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
processor = AutoImageProcessor.from_pretrained(MODEL_ID)
model = AutoModelForImageClassification.from_pretrained(MODEL_ID).to(DEVICE)
model.eval()

TEXT = {
 "ku": {"title":"🌿 ناسینەوەی نەخۆشیی ڕووەک بە AI","subtitle":"وێنەیەکی ڕوونی گەڵا باربکە بۆ پێشبینی جۆری نەخۆشی.","upload":"وێنەی گەڵا باربکە","button":"پشکنینی گەڵا","result":"ئەنجامی پێشبینی","confidence":"ڕێژەی متمانەی مۆدێل","top":"پێشبینییە سەرەکییەکان","note":"تێبینی: ئەمە پێشبینیی AI ـە، نەک دەستنیشانکردنی دڵنیای نەخۆشی. ئەنجام بە کوالێتی وێنە و داتای ڕاهێنانەوە پەیوەستە.","advice":"پێش بەکارهێنانی چارەسەر، باشترە ئەنجامەکە لەلایەن شارەزای کشتوکاڵ پشتڕاست بکرێتەوە.","footer":"بە مۆدێلی پۆلێنکردنی وێنە بە ٣٨ پۆل دروست کراوە."},
 "en": {"title":"🌿 AI Plant Disease Detection","subtitle":"Upload a clear photo of a plant leaf to estimate its class.","upload":"Upload a leaf image","button":"Analyze leaf","result":"Prediction","confidence":"Model confidence","top":"Top predictions","note":"Note: This is an AI estimate, not a confirmed diagnosis. Results depend on image quality and training data.","advice":"Confirm the result with a local agricultural expert before treating the plant.","footer":"Built with a 38-class image-classification model."}
}
def predict(image, lang):
    t = TEXT[lang]
    if image is None:
        return "", "", "", t["note"]
    image = image.convert("RGB")
    inputs = {k:v.to(DEVICE) for k,v in processor(images=image, return_tensors="pt").items()}
    with torch.inference_mode():
        probs = torch.softmax(model(**inputs).logits, dim=-1)[0]
    vals, ids = torch.topk(probs, k=min(5, probs.numel()))
    labels = model.config.id2label
    def label(i): return labels.get(int(i), labels.get(str(int(i)), f"Class {int(i)}"))
    best = label(ids[0])
    rows = "\n".join(f"{label(i)} — {p*100:.2f}%" for p,i in zip(vals.tolist(),ids.tolist()))
    conf = f'{t["confidence"]}: {vals[0].item()*100:.2f}%'
    advice = ( "پۆلێکی تەندروست پێشبینی کراوە؛ بەردەوام چاودێری ڕووەکە بکە." if "healthy" in best.lower() else t["advice"]) if lang=="ku" else t["advice"]
    return f'{t["result"]}: {best}', conf, rows, advice + "\n\n" + t["note"]

with gr.Blocks(title="AI Plant Disease Detection", theme=gr.themes.Soft()) as demo:
    language = gr.Radio(choices=[("کوردی","ku"),("English","en")], value="ku", label="زمان / Language")
    title = gr.Markdown(TEXT["ku"]["title"])
    subtitle = gr.Markdown(TEXT["ku"]["subtitle"])
    image_input = gr.Image(type="pil", label=TEXT["ku"]["upload"])
    analyze = gr.Button(TEXT["ku"]["button"], variant="primary")
    prediction = gr.Textbox(label=TEXT["ku"]["result"], interactive=False)
    confidence = gr.Textbox(label=TEXT["ku"]["confidence"], interactive=False)
    top_predictions = gr.Textbox(label=TEXT["ku"]["top"], lines=5, interactive=False)
    note = gr.Markdown(TEXT["ku"]["note"])
    footer = gr.Markdown(TEXT["ku"]["footer"])
    def update_language(lang):
        t=TEXT[lang]
        return t["title"],t["subtitle"],gr.update(label=t["upload"]),gr.update(value=t["button"]),gr.update(label=t["result"]),gr.update(label=t["confidence"]),gr.update(label=t["top"]),t["note"],t["footer"]
    language.change(update_language, inputs=language, outputs=[title,subtitle,image_input,analyze,prediction,confidence,top_predictions,note,footer])
    analyze.click(predict, inputs=[image_input,language], outputs=[prediction,confidence,top_predictions,note])
demo.launch(server_name="0.0.0.0", server_port=int(os.getenv("PORT","7860")))
